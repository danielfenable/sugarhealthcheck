<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Auth;
use View;
use Session;
use Redirect;
use App\Enable\Direct\Reindex;

class ReindexController extends Controller
{
    public function perform()
    {
    	$system = Session::get('system')->name;
        $reindex = new Reindex();
        $result = $reindex->perform($system);
        return view::make("panel/output/output")->with("output", $result);
    }
}
