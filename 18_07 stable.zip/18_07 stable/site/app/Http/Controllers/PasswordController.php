<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Auth;
use View;
use Session;
use Redirect;
use App\Enable\Server\CallPassword;
use App\Enable\Server\CallUsers;
use App\Enable\Direct\Helpers\Tools;
use App\Enable\Server\CallSystemInfo;
use App\Enable\Direct\Helpers\RecordFinders;
use App\Enable\Direct\Helpers\ChangePoster;

class PasswordController extends Controller
{
    public function handler()
    {
    	$system = Session::get('system')->name;
        $users = new CallUsers();
        $result = $users->perform($system);
        if (!$result) return "could not connect to sugar, query returned false";
        $decoded =  json_decode($result);
        foreach ($decoded as $key) {
        	if ($key->is_admin == 0) {
                $usernames[] = $key->user_name;
            }
        };
        return \View::make('panel/list/list')->with(
            array(
                  "list_value" => $usernames,
                  "action" => "passwordchange",
                  "list_info" => "Choose a user to generate and set a random password. <br>
                                  Note, this can only be performed on non-admin
                                  users." . '<br>'
                 )
        );
    }

    public function perform(Request $request)
    {
        $system = Session::get('system')->name;
        $user = $request->list_value;
        $change = new CallPassword();
        $new_password = Tools::rand_pass(8);
        $result = $change->perform($system, $user, $new_password);
        if ($result == 'true') {
            $extra_info = '';
            $info = new CallSystemInfo;
            $account = $info->contractFields($system);
            if (isset($account['records'][0])) {
                $account_name = $account['records'][0]['account_name'];
                $finder = new RecordFinders;
                $account_id = $finder->getAccountIdByName($system, $account_name);
                $change = new ChangePoster;
                $change->createRelatedChangeRecord(
                    $system, 'Accounts', $account_id, 'accounts_eit_change_management_1',
                    "Password change for user: $user"
                );
            }
             $output = "The password was successfully changed for the user : $user
                        <br> New Password : <strong> $new_password </strong>";
        } else {
             $output = "The password change failed for user: $user";
        }
        return view::make("panel/output/output")->with("output", $output);
    }
}
