<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Auth;
use View;
use Session;
use Redirect;
use App\Enable\Server\FixPerms;
use App\Enable\Server\CallList;

class FixpermsController extends Controller
{

    public function perform(Request $request)
    {
        $system = Session::get('system')->name;
        $fixperms = new FixPerms();
        $result = $fixperms->perform($system);
        if (isset($result[1])) {
            if (isset($result[1]) && $result[1] != 0) {
                $output = 'The fixperms failed to complete,
                           an error number of:' . $result[1] .
                           ' was returned with the error: <br> ' .
                           $result[0];
            }
            if (!isset($result[1])) {
                $output = 'The fixperms failed to complete,
                           error number ' .  $result[0];
            }
        } else {
                if ($result[0] == 0) {
                     $output = 'The fixperms completed successfully for' . $system;
                }
        }
        return view::make("panel/output/output")->with("output", $output);
    }
}
