<?php

namespace App\Enable\Direct\Helpers;

use App\Http\Requests\Sugar\Auth\Client;
use Session;

class ChangePoster
{
    public function createCaseRecoverRecord($system, $id, $extra_info = null)
    {
           $client = new Client($system, rtrim(env("SUGAR_URL", false), '/') . '/');
           return $client->post(
               "/Cases/$id/link/cases_eit_change_management_1", array(
                  'name' => 'Record Recovery ' . date("Y-m-d H:i") . ' by: ' . Session::get('user')->username ,
                  'description' => "Record Recovered: " . $extra_info
               )
           );
    }

    public function createRelatedChangeRecord($system, $module, $base_id, $relationship, $name, $extra_info = null)
    {
           $client = new Client($system, rtrim(env("SUGAR_URL", false), '/') . '/');
           return $client->post(
               "/$module/$base_id/link/$relationship", array(
                  'name' => $name  . ' - ' . date("Y-m-d H:i") . ' by: ' . Session::get('user')->username ,
                  'description' => $extra_info
               )
           );
    }

    public function CreateChangeLogonToAccount($system, $id, $extra_info = null)
    {
           $client = new Client($system, rtrim(env("SUGAR_URL", false), '/') . '/');
           return $client->post(
               "/Accounts/$id/link/accounts_eit_change_management_1", array(
                  'name' => 'User Login on: ' . date("Y-m-d H:i") . ' - by: ' . Session::get('user')->username ,
                  'description' => $extra_info
               )
           );
    }
}