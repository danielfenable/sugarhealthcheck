<?php

namespace App\Enable\Direct\Helpers;

class Tools
{

    static public function rand_pass($length)
    {
        $charsalph = str_split("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#$?");
        $randLowerCase = $charsalph[rand(0, 25)];
        $randUppercase = $charsalph[rand(26, 51)];
        $randNumber = $charsalph[rand(52, 61)];
        $randSymbol = $charsalph[rand(62, 64)];
        $randPassword = $randLowerCase.$randUppercase.$randNumber.$randSymbol;
        $count_limit = $length - 4;
        $count = 0;
        while ($count < $count_limit) {
                $randCharacter = $charsalph[rand(0, 64)];
                $randPassword = $randPassword.$randCharacter;
                $count++;
        }
        $randPassword = str_shuffle($randPassword);
        return $randPassword;

        //return $password;
    }
}

?>