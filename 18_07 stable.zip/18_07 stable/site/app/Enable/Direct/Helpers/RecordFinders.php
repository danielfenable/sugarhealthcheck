<?php

namespace App\Enable\Direct\Helpers;

use App\Http\Requests\Sugar\Auth\Client;
use Session;

Class RecordFinders
{
	public function GetCaseById($system, $case_num)
	{
              $client = new Client($system, env("SUGAR_URL", false));
              $result = $client->get(
                  '/Cases', array(
                     "filter" => array(
                           array(
                                   "case_number" => $case_num
                           ),
                     ),
                     "max_num" => 1,
                     "offset" => 0,
                  )
              );
              if (!isset($result['records'][0])) {
                   return $result;
              } else {
                     $case = $result['records'][0];
                     return $case['id'];
                }
    }

    public function getAccountIdByName($system, $name)
    {
              $client = new Client($system, env("SUGAR_URL", false));
              $result = $client->get(
                  '/Accounts', array(
                     "filter" => array(
                           array(
                                   "name" => $name
                           ),
                     ),
                     "max_num" => 1,
                     "offset" => 0,
                  )
              );
              if (!isset($result['records'][0])) {
                   return $result;
              } else {
                     $case = $result['records'][0];
                     return $case['id'];
              }
    }

}


?>