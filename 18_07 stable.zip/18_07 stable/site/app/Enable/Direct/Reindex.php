<?php

namespace App\Enable\Direct;

use Session;
use View;
use App\Http\Requests\Sugar\Auth\Client;

class reindex
{
   public function perform()
   {
        $system = Session::get('system')->name;
        $url = rtrim(env("REMOTE_SUGAR_URL", false), '/') . '/'. $system;
        $username = env("CUSTOMER_USERNAME", false);
        $password = env("CUSTOMER_PASSWORD", false);
        $sugar = new Client($system, $url);
        $result = $sugar->post("/Administration/search/reindex");
        if ($result['success'] == true) {
            $output = 'The search reindex started successfully.';
        } else {
            $output = 'The search index failed to start.';
        }
        return $output;
   }

}

?>