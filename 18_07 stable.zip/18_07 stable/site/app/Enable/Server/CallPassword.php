<?php

namespace App\Enable\Server;

use App\Http\Requests\GenericCalls\Call;

class CallPassword
{

	function perform($system, $user, $password)
    {
        $data = array();
        $data['user'] = $user;
        $data['password'] = $password;
        $data = json_encode($data);
        $call = new Call();
        $result = $call->post('password', $system, $data);
        return $result;
    }

}