<?php

namespace App\Enable\Server;

use App\Http\Requests\Sugar\Auth\Client;
use App\Http\Requests\GenericCalls\Call;
use Session;


class CallAccess
{
    public function perform($system, $user)
    {
         // Insert row in oauth table
        $call = new Call();
        $result = $call->post("access", $system, json_encode($user));
        return $result;
    }
}


?>