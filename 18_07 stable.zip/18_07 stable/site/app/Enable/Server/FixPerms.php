<?php

namespace App\Enable\Server;

use App\Http\Requests\GenericCalls\Call;

class FixPerms
{

    function perform($system)
    {
        error_reporting(E_ALL);
        if (!($sock = socket_create(AF_INET, SOCK_STREAM, 0))) {
            $errorcode = socket_last_error();
            $errormsg = socket_strerror($errorcode);
            die("Couldn't create socket: [$errorcode] $errormsg \n");
        }
        if (!socket_connect($sock, '127.0.0.1', 11112)) {
            $errorcode = socket_last_error();
            $errormsg = socket_strerror($errorcode);
            die("Could not connect: [$errorcode] $errormsg \n");
        }
        $message = "sugarent \n";
        if (! socket_send($sock, $message, strlen($message), 0)) {
            $errorcode = socket_last_error();
            $errormsg = socket_strerror($errorcode);
            die("Could not send data: [$errorcode] $errormsg \n");
        }
        usleep(500);
        if ($len = socket_recv($sock, $buf, 2024, MSG_WAITALL) === false) {
            $errorcode = socket_last_error();
            $errormsg = socket_strerror($errorcode);
            die("Could not receive data: [$errorcode] $errormsg \n");
        }
        if (!$buf) {
        	socket_close($sock);
            die('No response received');
        }
        $err_num = explode('<br>', $buf);
        return $err_num;
        socket_close($sock);
    }
}


?>