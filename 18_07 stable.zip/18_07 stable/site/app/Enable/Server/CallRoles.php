<?php

namespace App\Enable\Server;

use App\Http\Requests\GenericCalls\Call;

class CallRoles
{

	function perform($user){

        $call = new Call();
        $result = $call->userGet(
            $user,
            'roles'
        );
        return $result;
    }
}


?>