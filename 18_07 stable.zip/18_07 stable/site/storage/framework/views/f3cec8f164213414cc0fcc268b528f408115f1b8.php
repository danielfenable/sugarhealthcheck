<?php $__env->startSection('addon'); ?>
    @parent

<p>Choose a range of two dates to show deleted records between them for <?php echo e($system); ?>.</p>

<body>

<?php echo e(Form::open(array('url' => 'recoverlist'))); ?>


<p>

</p>
    <?php echo e($errors->first('max')); ?>

<p>
    <?php echo e(Form::date('date_range_1', Input::old('date_range_1'), array('placeholder' => '01/01/2016','required' => 'required'))); ?>

</p>

<p>
    <?php echo e(Form::date('date_range_2', Input::old('date_range_2'), array('placeholder' => '01/01/2016','required' => 'required'))); ?>

</p>

Module Name <br>

<select name="module" required>

<option disabled selected value>

<?php foreach($modules as $key => $value): ?>

    <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>

<?php endforeach; ?>

</select>

<br><br>

<p> Case Number <br>
   <?php echo e(Form::number("case_num", '',array('required' => 'required'))); ?>

</p>

<br>

<?php echo e(Form::hidden("system",$system)); ?>



<p><?php echo e(Form::submit('Submit')); ?></p>
<?php echo e(Form::close()); ?>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('panel/master/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>