<?php $__env->startSection('addon'); ?>
    @parent

    <?php echo isset($info) ? $info : ""; ?>


    <br><br>

<?php echo e(Form::open(array('url' => $action))); ?>


     <?php echo e(Form::text('values')); ?>


      <?php echo isset($additional) ? $additional : ""; ?>


     <?php echo e(Form::submit()); ?>


<?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('panel/master/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>