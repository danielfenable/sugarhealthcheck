<!doctype html>
<html>
<head>
<?php echo e(Html::style('assets/css/login.css')); ?>

<title>Healthcheck login</title>
</head>
<body>
<div id='banner'>
   <center><img id='logo' src="assets/img/logo.png"><center>
</div>
<div id='spacer'>
</div>
<center><div id='wrapper'>

    <h1 id='login'> Login</h1>

    <?php echo e(Form::open(array('url' => 'login'))); ?>

          <?php echo e($errors->first('username')); ?>

          <?php echo e($errors->first('password')); ?>

          <?php echo e($errors->first('invalid')); ?>

<br>
          <?php echo e(Form::label('username', 'Username')); ?>

          <?php echo e(Form::text('username', Input::old('username'), array('placeholder' => 'example'))); ?>


          <?php echo e(Form::label('password', 'Password')); ?>

          <?php echo e(Form::password('password')); ?>


          <?php echo e(Form::submit('Submit')); ?>

    <?php echo e(Form::close()); ?>

</div>
</center>
<div id='mid_spacer'> </div>
<div class="footer">

       <div class="row">
            <div class="col-lg-12" >
                     <a href="http://enable.services" style="color:#fff;" target="_blank"> Enable Technologies </a>
            </div>
       </div>
</div>