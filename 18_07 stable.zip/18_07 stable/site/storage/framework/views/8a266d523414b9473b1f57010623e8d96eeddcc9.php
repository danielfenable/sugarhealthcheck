<?php $__env->startSection('addon'); ?>
    @parent
<?php echo $rows; ?>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('panel/master/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>