<?php $__env->startSection('addon'); ?>
    @parent

   <?php foreach($output as $key => $value): ?>

     <strong> <?php echo e(ucfirst($key)); ?> </strong> = <?php echo e(ucfirst($value)); ?> <br> <br>

   <?php endforeach; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('panel/master/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>