<?php $__env->startSection('addon'); ?>
    @parent

<?php if($array): ?>
    <?php foreach($array as $item): ?>
          <?php echo $item; ?> <br> <br>

    <?php endforeach; ?>
<?php endif; ?>

<?php if($array2): ?>
    <?php foreach($array2 as $item): ?>

          <?php echo $item; ?> <br> <br>

    <?php endforeach; ?>
<?php endif; ?>

<?php echo isset($output) ? $output : ""; ?>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('panel/master/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>