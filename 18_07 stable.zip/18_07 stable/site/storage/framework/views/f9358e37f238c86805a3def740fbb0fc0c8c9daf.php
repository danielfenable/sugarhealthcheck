<?php $__env->startSection('addon'); ?>
    @parent

<?php echo isset($list_info) ? $list_info : ""; ?> <br>

<form action="<?php echo e($action); ?>" method="POST" name="list" >

<?php echo e(Form::token()); ?>


<select name="list_value">


<?php foreach($list_value as $item): ?>

<option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>

<?php endforeach; ?>

<br>
<br>

</select>
<br>
<br>

     <?php echo isset($additional) ? $additional : ""; ?>



<input type="submit">

</form>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('panel/master/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>