@extends('panel/master/master')

@section('addon')
    @parent
{!! $rows !!}


@stop

