@extends('panel/master/master')

@section('addon')
    @parent

@if($array)
    @foreach ($array as $item)
          {!!$item!!} <br> <br>

    @endforeach
@endif

@if($array2)
    @foreach ($array2 as $item)

          {!!$item!!} <br> <br>

    @endforeach
@endif

{!! $output or "" !!}


@stop

