@extends('panel/master/master')

@section('addon')
    @parent

{!! $output or "" !!}


@stop

