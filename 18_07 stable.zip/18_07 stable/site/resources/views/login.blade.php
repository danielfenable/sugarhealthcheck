<!doctype html>
<html>
<head>
{{ Html::style('assets/css/login.css') }}
<title>Healthcheck login</title>
</head>
<body>
<div id='banner'>
   <center><img id='logo' src="assets/img/logo.png"><center>
</div>
<div id='spacer'>
</div>
<center><div id='wrapper'>

    <h1 id='login'> Login</h1>

    {{ Form::open(array('url' => 'login')) }}
          {{ $errors->first('username') }}
          {{ $errors->first('password') }}
          {{ $errors->first('invalid') }}
<br>
          {{ Form::label('username', 'Username') }}
          {{ Form::text('username', Input::old('username'), array('placeholder' => 'example')) }}

          {{ Form::label('password', 'Password') }}
          {{ Form::password('password') }}

          {{ Form::submit('Submit') }}
    {{ Form::close() }}
</div>
</center>
<div id='mid_spacer'> </div>
<div class="footer">

       <div class="row">
            <div class="col-lg-12" >
                     <a href="http://enable.services" style="color:#fff;" target="_blank"> Enable Technologies </a>
            </div>
       </div>
</div>