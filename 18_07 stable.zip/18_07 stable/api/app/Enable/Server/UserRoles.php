<?php

namespace App\Enable\Server;

class UserRoles
{

	function perform()
	{
        error_reporting(E_WARNING && E_STRICT && E_ERROR);
        if (!isset($_SERVER["user"])) {
             die('No user found in request.');
        }
        $user = $_SERVER["user"];
        $db = \DBManagerFactory::getInstance();
        $user_sql
            = "SELECT acl_role_set_id FROM users WHERE user_name = '$user'";
        $result = $GLOBALS['db']->query($user_sql);
        if (!$result) return false;
        $users = array();
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
              $users[] = $row;
        }
        if (!isset($users[0]['acl_role_set_id'])) {
               return 'false';
        }
        $role_set_id = $users[0]['acl_role_set_id'];
        $role_sql
            = "SELECT acl_role_id FROM acl_role_sets_acl_roles WHERE acl_role_set_id = '$role_set_id'";
        $result = $GLOBALS['db']->query($role_sql);
        if (!$result) return false;
        $role_ids = array();
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
              $role_ids[] = $row;
        }
        $roles = array();
        foreach ($role_ids as $value) {
            $role = $value['acl_role_id'];
            $role_sql
                = "SELECT name FROM acl_roles WHERE id = '$role'";
            $result = $GLOBALS['db']->query($role_sql);
            if (!$result) return false;
            while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                 $roles[] = $row;
            }
        }
        return $roles;
   }
}


