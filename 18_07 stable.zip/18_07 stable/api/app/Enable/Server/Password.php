<?php

namespace App\Enable\Server;

use App\Http\Requests;

class Password
{

    public static function perform($user, $new_password)
    {
    	$db = \DBManagerFactory::getInstance();
    	$hashed_pass = md5($new_password);
        $pass_sql
            = "UPDATE users SET user_hash = '$hashed_pass'  WHERE user_name = '$user'";
        $result = $GLOBALS['db']->query($pass_sql);
        if (!$result) return 'false';
        $sql = " SELECT user_hash FROM users WHERE user_hash = '$hashed_pass'";
        $result = $GLOBALS['db']->query($sql);
        if ($result->num_rows > 0) {
            return 'true';
        } else {
            return 'false';
        }
    }
}


