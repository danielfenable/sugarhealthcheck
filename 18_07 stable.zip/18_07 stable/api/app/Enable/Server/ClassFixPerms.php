<?php

namespace App\Enable\Server;

class ClassFixPerms
{
	static public function perform($system){
		$sugar_system = rtrim(env("SUGAR_ROOT"), '/') . '/' . $system;
		$output;
		$error_code;
		exec("sudo /usr/bin/sudo /usr/local/bin/fixperms $sugar_system", $output, $error_code);
		fclose($handle);
    }

}

?>
