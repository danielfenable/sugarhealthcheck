<?php

$handle = fopen('php://stdin', 'r');
$dir = fgets($handle);
if (isset($dir)) {
	require(__DIR__.'/../../../bootstrap/app.php');
    $dir = rtrim($dir, "/") . '/';
    $sugar_system = env("SUGAR_ROOT") . $dir;
    $output;
    $error_code;
    exec("/usr/bin/sudo /usr/local/bin/fixperms $sugar_system", $output, $error_code);
    fclose($handle);
    echo "<br> $error_code ";
} else {
    echo "Failed Fixperms - Directory not passed.";
}

?>
