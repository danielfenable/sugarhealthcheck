<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Enable\Server\Password;

class PasswordController extends Controller
{
    public function perform(Request $request)
    {
        $new_password = $request->password;
        $user = $request->user;
        if (!$user || !$new_password) {
        	die('Invalid data posted in.');
        }
        $password = new Password();
        $result = $password->perform($user, $new_password);
        return $result;
    }
}
