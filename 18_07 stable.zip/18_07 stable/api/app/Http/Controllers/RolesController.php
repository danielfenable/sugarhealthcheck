<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Enable\Server\UserRoles;

class RolesController extends Controller
{
    function perform()
    {
       $roles = new UserRoles();
       $roles_result = $roles->perform();
       return $roles_result;
    }
}